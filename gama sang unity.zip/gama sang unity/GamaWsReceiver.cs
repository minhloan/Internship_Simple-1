﻿using System;
using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEngine;

public class GamaWsReceiver : MonoBehaviour
{
    [Header("GAMA WebSocket")]
    public string uri = "ws://localhost:8080/";
    public Transform target;
    public bool swapZY = true;

    ClientWebSocket ws;
    CancellationTokenSource cts;
    readonly ConcurrentQueue<Action> mainQ = new ConcurrentQueue<Action>();

    class Frame { public string type; public JToken content; }

    void OnEnable() { Application.runInBackground = true; _ = StartWs(); }
    void OnDisable() { StopWs(); }
    void Update() { while (mainQ.TryDequeue(out var a)) a(); }

    async Task StartWs()
    {
        cts = new CancellationTokenSource();
        ws = new ClientWebSocket();
        await ws.ConnectAsync(new Uri(uri), cts.Token);
        Debug.Log($"[GamaWsReceiver] Connected {uri}");
        _ = RecvLoop();
    }

    async Task RecvLoop()
    {
        var buf = new ArraySegment<byte>(new byte[1 << 20]);
        var sb = new StringBuilder();

        while (ws != null && ws.State == WebSocketState.Open)
        {
            sb.Length = 0;
            WebSocketReceiveResult r;
            do
            {
                r = await ws.ReceiveAsync(buf, cts.Token);
                sb.Append(Encoding.UTF8.GetString(buf.Array, 0, r.Count));
            } while (!r.EndOfMessage);

            var payload = sb.ToString();
            Debug.Log("[WS raw] " + payload);                 // <-- BẮT BUỘC: xem server có gửi gì không
            foreach (var part in payload.Split(new[] { "|||" }, StringSplitOptions.RemoveEmptyEntries))
                HandleFrame(part.Trim());
        }
    }

    void HandleFrame(string json)
    {
        // 1) khung chuẩn {"type":"SimulationOutput","content": ...}
        try
        {
            var f = JsonConvert.DeserializeObject<Frame>(json);
            if (f != null && f.type == "SimulationOutput" && f.content != null)
            {
                var inner = f.content.Type == JTokenType.String ? f.content.Value<string>()
                                                                : f.content.ToString(Formatting.None);
                TryHandleOutput(inner);
                return;
            }
        }
        catch { /* bỏ qua, thử fallback */ }

        // 2) fallback: GAMA đôi khi gửi thẳng chuỗi output
        if (json.Contains("\"type\":\"output\""))
            TryHandleOutput(json);
    }

    void TryHandleOutput(string outputJson)
    {
        // dạng: {"type":"output","contents":[{"id":["py1"],"contents":{"type":"AgentPos","id":"a1","x":..,"y":..,"z":..,"elev":..}}]}
        JObject root;
        try { root = JObject.Parse(outputJson); } catch { return; }

        var arr = root["contents"] as JArray; if (arr == null) return;
        foreach (var it in arr)
        {
            var c = it["contents"] as JObject; if (c == null) continue;
            if ((string)c["type"] != "AgentPos") continue;

            float x = c["x"]?.Value<float>() ?? 0f;
            float y = c["y"]?.Value<float>() ?? 0f;
            float z = c["z"]?.Value<float>() ?? 0f;

            Debug.Log($"[AgentPos] x={x} y={y} z={z}");
            mainQ.Enqueue(() => ApplyPos(x, y, z));
        }
    }

    void ApplyPos(float x, float y, float z)
    {
        if (!target) return;
        target.position = swapZY ? new Vector3(x, z, y) : new Vector3(x, y, z);
    }

    void StopWs()
    {
        try { cts?.Cancel(); } catch { }
        try { ws?.Dispose(); } catch { }
        ws = null; cts = null;
    }
}
