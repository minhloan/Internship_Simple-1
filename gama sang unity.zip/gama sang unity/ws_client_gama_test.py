# -*- coding: utf-8 -*-
# Client WebSocket nghe GAMA và bóc payload khỏi lớp SimulationOutput
# Cài:  python -m pip install websockets

import asyncio, json
import websockets

URI = "ws://localhost:8080/"

def _iter_frames(raw: str):
    for part in raw.split("|||"):
        s = part.strip()
        if s:
            yield s

def _extract_payload(s: str):
    # GAMA bọc như: {"type":"SimulationOutput","content":"{...json...}"}
    try:
        outer = json.loads(s)
    except Exception:
        return None, s
    if outer.get("type") != "SimulationOutput":
        return ("META", outer)
    content = outer.get("content")
    inner = json.loads(content) if isinstance(content, str) else content
    items = inner.get("contents", [])
    if items and isinstance(items[0], dict) and "contents" in items[0]:
        return ("PAYLOAD", items[0]["contents"])
    return ("INNER", inner)

async def run():
    async with websockets.connect(URI, max_size=None) as ws:
        print("Connected")
        while True:
            raw = await ws.recv()
            for s in _iter_frames(str(raw)):
                kind, data = _extract_payload(s)
                if kind == "PAYLOAD":
                    print("PAYLOAD:", data)  # {'type':'AgentPos','id':'a1','x':..,'y':..,'z':..,'elev':..}
                else:
                    print("RECV:", data)

if __name__ == "__main__":
    asyncio.run(run())
